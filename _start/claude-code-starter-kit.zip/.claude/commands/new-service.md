# Command: /new-service

Create a new Docker-ready service with standard structure.

## Usage
```
/new-service [service-name] [language]
```

## Arguments
- `service-name`: Name of the service (kebab-case)
- `language`: Programming language (go|python|node)

## Example
```
/new-service user-api node
```

## What It Creates

### Directory Structure
```
services/[service-name]/
├── src/
│   └── index.[ext]
├── tests/
├── Dockerfile
├── Makefile
├── CLAUDE.md
├── package.json (or go.mod, requirements.txt)
└── README.md
```

### Files Generated

**Dockerfile** - Multi-stage build with:
- `development` target with hot reload
- `production` target with minimal image
- Health check endpoint
- Non-root user

**Makefile** - Standard commands:
- `make run` - Start with hot reload
- `make test` - Run tests
- `make build` - Build production binary
- `make lint` - Run linter

**CLAUDE.md** - Service context including:
- Purpose description
- Directory structure
- API endpoints template
- Environment variables
- Testing commands

### Docker Compose Integration
Also updates `docker-compose.yml` to add:

```yaml
services:
  [service-name]:
    build:
      context: ./services/[service-name]
      target: development
    volumes:
      - ./services/[service-name]:/app
    environment:
      - ENV=development
```

## Post-Creation Steps
1. Update `services/[service-name]/CLAUDE.md` with actual API design
2. Run `make rebuild` to build the new service
3. Implement the service logic
4. Update STATUS.md with new service