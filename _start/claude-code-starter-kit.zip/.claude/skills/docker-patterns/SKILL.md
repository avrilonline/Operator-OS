# Skill: Docker Development Patterns

## Description
Best practices for Docker-based local development and Coolify deployment.

## Dockerfile Patterns

### Multi-Stage Build
Always use multi-stage builds with named targets:

```dockerfile
# Base stage - shared dependencies
FROM node:20-alpine AS base
WORKDIR /app

# Development - includes dev tools
FROM base AS development
# ... hot reload, debug tools

# Builder - compiles production assets
FROM base AS builder
# ... build steps

# Production - minimal runtime
FROM base AS production
# ... only runtime dependencies
```

### Target Selection
```yaml
# docker-compose.yml
services:
  api:
    build:
      context: ./services/api
      target: development  # or production
```

## Docker Compose Patterns

### Health Checks
Always define health checks for dependent services:

```yaml
services:
  db:
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U postgres"]
      interval: 5s
      timeout: 5s
      retries: 5
      
  api:
    depends_on:
      db:
        condition: service_healthy
```

### Volume Mounts for Development
```yaml
services:
  api:
    volumes:
      - ./services/api:/app          # Source code
      - /app/node_modules            # Preserve container modules
```

### Environment Files
```yaml
services:
  api:
    env_file:
      - .env
      - .env.local  # Overrides, not committed
```

## Coolify Deployment

### Required Labels
```yaml
services:
  api:
    labels:
      - "coolify.managed=true"
```

### Production Overrides
Create `docker-compose.prod.yml`:

```yaml
version: "3.8"

services:
  api:
    build:
      target: production
    restart: always
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"
```

## Security Checklist
- [ ] Non-root user in production images
- [ ] No secrets in Dockerfiles (use env vars)
- [ ] Minimal base images (alpine preferred)
- [ ] Health checks defined
- [ ] Read-only root filesystem where possible
- [ ] Resource limits in compose